sap.ui.define([
	"ui5_1/test/unit/controller/App.controller"
], function () {
	"use strict";
});
