sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History",
    "sap/ui/model/Sorter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/table/library"
],
    function (Controller, History, Sorter, Filter, FilterOperator, library) {
        "use strict";

        return Controller.extend("ui51.controller.SecondaPagina", {
            onInit: function(){
                this.ordine="true"
            },

            onBack: function () {
                var oHistory = History.getInstance();
                var sHash = oHistory.getPreviousHash();
                if (sHash !== undefined) {
                    window.history.go(-1);
                } else {
                    var oRouter = this.getOwnerComponent().getRouter();
                    oRouter.navTo("App");
                }
            },

            onSort: function () {
                var oSort = new Sorter({
                    path: "ProductID",
                    descending: this.ordine,
                    group: false
                });

                var oTable = this.byId("table");
                oTable.getBinding("items").sort(oSort);
                   this.ordine= !this.ordine
            },

            onClear: function (oEvent) {
            var oTable = this.byId("table");
            oTable.getBinding().sort(null);
            this._resetSortingState();
            },

            onSearch: function (oEvent) {
                var sQuery = oEvent.getParameters().query;
                var aFilter = [];
                var oList = this.getView().byId("table");
                var oBinding = oList.getBinding("items");
                if (sQuery) {
                    aFilter.push(new Filter("ProductName",
                        FilterOperator.Contains, sQuery,
                    ))
                }
                oBinding.filter(aFilter);
            }
        }
        )
    })